package br.gov.sp.cps.bandodados;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    private TextView textResultado;
    private TextInputEditText textNome, textIdade;
    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        dbHelper = new DatabaseHelper(this);
        textResultado = findViewById(R.id.textResultado);
        textNome = findViewById(R.id.textNome);
        textIdade = findViewById(R.id.textIdade);

        Button btnGravar = findViewById(R.id.btnGravar);
        Button btnConsultar = findViewById(R.id.btnConsultar);
        Button btnAtualizar = findViewById(R.id.btnAtualizar);
        Button btnDeletar = findViewById(R.id.btnDeletar);
        Button btnListar = findViewById(R.id.btnListar);
        Button btnLimpar = findViewById(R.id.btnLimpar);
        Button btnResumo = findViewById(R.id.btnResumo);

        btnGravar.setOnClickListener(v -> {
            String nome = nomeDigitado();
            Integer idade = idadeDigitada();
            if (nome == null || idade == null) return;
            if (dbHelper.inserirDados(nome, idade)) {
                mensagem("Cadastro realizado com sucesso!");
                limparCampos();
                mostrarResumo();
            } else mensagem("Não foi possível cadastrar. Confira os dados.");
        });

        btnConsultar.setOnClickListener(v -> {
            String nome = nomeDigitado();
            if (nome == null) return;
            try (Cursor cursor = dbHelper.obterIdadePorNome(nome)) {
                if (cursor.moveToFirst()) {
                    StringBuilder resultado = new StringBuilder("🔎 RESULTADO DA CONSULTA\n\n");
                    do {
                        resultado.append("ID: ").append(cursor.getInt(0))
                                .append("\nNome: ").append(cursor.getString(1))
                                .append("\nIdade: ").append(cursor.getInt(2)).append(" anos\n\n");
                    } while (cursor.moveToNext());
                    textResultado.setText(resultado.toString());
                } else mensagem("Nenhuma pessoa encontrada com esse nome.");
            }
        });

        btnAtualizar.setOnClickListener(v -> {
            String nome = nomeDigitado();
            Integer idade = idadeDigitada();
            if (nome == null || idade == null) return;
            if (dbHelper.atualizarDados(nome, idade)) {
                mensagem("Cadastro atualizado!");
                mostrarResumo();
            } else mensagem("Nome não encontrado. Nada foi alterado.");
        });

        btnDeletar.setOnClickListener(v -> {
            String nome = nomeDigitado();
            if (nome == null) return;
            if (dbHelper.deletaDados(nome)) {
                mensagem("Cadastro(s) excluído(s) com sucesso.");
                limparCampos();
                mostrarResumo();
            } else mensagem("Nome não encontrado. Nada foi excluído.");
        });

        btnListar.setOnClickListener(v -> listarTodos());
        btnLimpar.setOnClickListener(v -> limparCampos());
        btnResumo.setOnClickListener(v -> mostrarResumo());
        mostrarResumo();
    }

    private String nomeDigitado() {
        String nome = textNome.getText() == null ? "" : textNome.getText().toString().trim();
        if (nome.isEmpty()) {
            textNome.setError("Digite o nome");
            textNome.requestFocus();
            return null;
        }
        return nome;
    }

    private Integer idadeDigitada() {
        String texto = textIdade.getText() == null ? "" : textIdade.getText().toString().trim();
        if (texto.isEmpty()) {
            textIdade.setError("Digite a idade");
            textIdade.requestFocus();
            return null;
        }
        try {
            int idade = Integer.parseInt(texto);
            if (idade < 0 || idade > 120) {
                textIdade.setError("Use uma idade entre 0 e 120");
                return null;
            }
            return idade;
        } catch (NumberFormatException e) {
            textIdade.setError("Idade inválida");
            return null;
        }
    }

    private void listarTodos() {
        try (Cursor cursor = dbHelper.listarTodos()) {
            if (cursor.getCount() == 0) {
                textResultado.setText("Ainda não há pessoas cadastradas.");
                return;
            }
            StringBuilder resultado = new StringBuilder("📋 PESSOAS CADASTRADAS\n\n");
            while (cursor.moveToNext()) {
                resultado.append("#").append(cursor.getInt(0)).append(" • ")
                        .append(cursor.getString(1)).append(" — ")
                        .append(cursor.getInt(2)).append(" anos\n");
            }
            resultado.append("\nTotal: ").append(cursor.getCount());
            textResultado.setText(resultado.toString());
        }
    }

    private void mostrarResumo() {
        textResultado.setText("📊 PAINEL DE CADASTROS\n\nPessoas cadastradas: " + dbHelper.contarRegistros() +
                "\n\nUse os campos acima para cadastrar, consultar, atualizar ou excluir pessoas.");
    }

    private void limparCampos() {
        textNome.setText("");
        textIdade.setText("");
        textNome.setError(null);
        textIdade.setError(null);
        textNome.requestFocus();
        mensagem("Campos limpos.");
    }

    private void mensagem(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onDestroy() {
        if (dbHelper != null) dbHelper.close();
        super.onDestroy();
    }
}
