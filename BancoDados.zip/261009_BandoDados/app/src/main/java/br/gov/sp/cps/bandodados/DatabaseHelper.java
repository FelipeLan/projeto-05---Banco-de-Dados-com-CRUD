package br.gov.sp.cps.bandodados;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "dados.db";
    public static final String TABLE_NAME = "pessoas";
    public static final String COL_1 = "ID";
    public static final String COL_2 = "NOME";
    public static final String COL_3 = "IDADE";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE " + TABLE_NAME + " (" + COL_1 + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COL_2 + " TEXT NOT NULL COLLATE NOCASE, " + COL_3 + " INTEGER NOT NULL CHECK(" + COL_3 + " BETWEEN 0 AND 120))");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Preserve os dados existentes. Adicione migrações aqui quando o esquema mudar.
    }

    public boolean inserirDados(String nome, int idade) {
        ContentValues values = new ContentValues();
        values.put(COL_2, nome.trim());
        values.put(COL_3, idade);
        SQLiteDatabase db = getWritableDatabase();
        return db.insert(TABLE_NAME, null, values) != -1;
    }

    public Cursor obterIdadePorNome(String nome) {
        SQLiteDatabase db = getReadableDatabase();
        return db.query(TABLE_NAME, new String[]{COL_1, COL_2, COL_3}, COL_2 + " = ?", new String[]{nome.trim()}, null, null, COL_1 + " DESC");
    }

    public boolean atualizarDados(String nome, int novaIdade) {
        ContentValues values = new ContentValues();
        values.put(COL_3, novaIdade);
        return getWritableDatabase().update(TABLE_NAME, values, COL_2 + " = ?", new String[]{nome.trim()}) > 0;
    }

    public boolean deletaDados(String nome) {
        return getWritableDatabase().delete(TABLE_NAME, COL_2 + " = ?", new String[]{nome.trim()}) > 0;
    }

    public Cursor listarTodos() {
        return getReadableDatabase().query(TABLE_NAME, new String[]{COL_1, COL_2, COL_3}, null, null, null, null, COL_2 + " COLLATE NOCASE ASC");
    }

    public int contarRegistros() {
        try (Cursor cursor = getReadableDatabase().rawQuery("SELECT COUNT(*) FROM " + TABLE_NAME, null)) {
            return cursor.moveToFirst() ? cursor.getInt(0) : 0;
        }
    }
}
